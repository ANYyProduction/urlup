
import os

from dotenv import find_dotenv, load_dotenv
load_dotenv(find_dotenv())

class var:
    BOT_TOKEN = "1828182161:AAGslsbjPmoSq97TdhcQ2k4fFSuYg6ANqfE" # from @botfather
    API_ID = "5378240" # from https://my.telegram.org/apps
    API_HASH = "e326b39ecfb8bea505d83d8ded4c1309"
    START_MESSAGE = os.getenv("START_MESSAGE", None)  # Not Mandatory
    OWNER_ID = "1462336566"
    REDIS_URI = "redis-15103.c73.us-east-1-2.ec2.cloud.redislabs.com:15103"
    REDIS_PASS = "RdPgT72RUF4xS2jvwyzhG5SuhjPwKmJL"